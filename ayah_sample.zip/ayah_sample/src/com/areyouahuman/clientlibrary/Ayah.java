package com.areyouahuman.clientlibrary;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;


public class Ayah {
	protected String ayah_publisher_key;
	protected String ayah_scoring_key;
	protected String ayah_web_service_host = "ws.areyouahuman.com";
	protected String session_secret;
	
	/**
	 * Constructor
	 *
	 * @param String pk
	 * 		The Publisher Key that you got on the portal http://portal.areyouahuman.com/
	 * @param String sk
	 * 		The Scoring Key that you got on the portal http://portal.areyouahuman.com/ 
	 * @param String ss
	 * 		The session secret generated during the PlayThru setup  
	 */
    public Ayah(String pk, String sk, String ss) {
    	ayah_publisher_key = pk;
    	ayah_scoring_key = sk;
    	session_secret = ss;
    }
    
	/**
	 * Returns the markup for the PlayThru
	 *
	 * @return string
	 */
	public String GetPublisherHTML(){
		String url = "";
		try{
			url = "https://" + ayah_web_service_host + "/ws/script/" +  
				java.net.URLEncoder.encode(ayah_publisher_key, "UTF-8");  
		}catch(Exception e){
			System.out.println (e.getMessage());
		}
		return "<div id='AYAH'></div><script src='" + url + "'></script>";
	}
	
	/**
	 * Records a conversion
	 * Called on the goal page that A and B redirect to
	 * A/B Testing Specific Function
	 *
	 * @return String
	 */
	public String recordConversion(){
		String retVal = "";
		try {
			if(session_secret != null){
				retVal = "<iframe style=\"border: none;\" height=\"0\" width=\"0\" src=\"https://" + 
						ayah_web_service_host + "/ws/recordConversion/" +
						URLEncoder.encode(session_secret, "UTF-8") + "\"></iframe>";
			}
		}catch(Exception e){
			System.out.println (e.getMessage());
		}
		return retVal;
	}
	
	/**
	 * Check whether the user is a human
	 * 
	 * We are using json-simple to parse the response from the server.
	 * http://code.google.com/p/json-simple/
	 * 
	 * True means the user passed the test, i.e. Is  A Human
	 * 
	 * @return boolean
	 */
	public Boolean ScoreResult() {
		if(session_secret != null){
			try {
			    // Construct data.
			    String data = URLEncoder.encode("session_secret", "UTF-8") + "=" + URLEncoder.encode(session_secret, "UTF-8");
			    data += "&" + URLEncoder.encode("scoring_key", "UTF-8") + "=" + URLEncoder.encode(ayah_scoring_key, "UTF-8");
			    // Send data.
			    URL url = new URL("https://" + ayah_web_service_host + "/ws/scoreGame");
			    URLConnection conn = url.openConnection();
			    conn.setDoOutput(true);
			    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			    wr.write(data);
			    wr.flush();
			    // Get the response.
			    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			    String line, jsonText = "";
			    while ((line = rd.readLine()) != null) {
			    	jsonText += line;
			    }
			    wr.close();
			    rd.close();
			    // Parse the json response, get the status code and return the scoring outcome.
			    JSONObject jobj = (JSONObject) JSONValue.parse(jsonText);
			    int status_code = ((Number)jobj.get("status_code")).intValue();
			    return (status_code == 1) ? true : false;
			} catch (Exception e) {
				System.out.println (e.getMessage());
			}
		}
		return false;
	}
}
